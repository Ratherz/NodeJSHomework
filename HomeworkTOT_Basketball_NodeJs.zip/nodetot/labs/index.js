const lab1 = require('./lab1-oop')
const lab2 = require('./lab2-callbackReadFiles')
module.exports = {
  lab1,
  lab2
}