let file = require('../libs/File')

module.exports = file