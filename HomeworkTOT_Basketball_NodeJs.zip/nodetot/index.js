/*const {lab1, lab2} = require('./labs')

lab1()
/*

lab2.ReadCSV('./data/premiere_2018-2019.csv', (result) => {})
lab2.ReadCSV('./data/liverpoolPlayers.json',(result)=> {})
*/
/*
lab2.readFile('./data/premiere_2018-2019.csv')
.then((data)=> {return lab2.readFile('./data/liverpoolPlayers.json')})
.then((data) =>{return lab2.readFile('./data/premiere_2018-2019.csv')})
.catch((err) => console.log(err)) */
/*
async function readFile () {
    let data = await lab2.readFile('./data/premiere_2018-2019.csv');
    let data2 = await lab2.readFile('./data/liverpoolPlayers.json'); 
}
readFile() */
/*
const File = require('./libs/File')
File.ReadCSV('./data/premiere_2018.csv', (result) =>{})
File.ReadCSV('./data/liverpoolPlayers.json', (result) =>{})
*/
/*
const Server = require('./middlewares/Server')
const server = new Server()
const PlayerRouter = require('routers/PlayersRouter.js')
*/
/*
const Server = require('./middlewares/Server')
const PlayersRouter = require('./routers/PlayersRouter')

const server = new Server()
server.use(PlayersRouter)
*/
/*
const Players = require('./models/Players');
const data = require('./data/liverpoolPlayers.json')
async function insert () {
  let connected = await Players.connect()
  let result = await Players.create(data[4]);
  let closed = await Players.close();
  return result;
}
insert().then(result => console.log(result))
*/
/*
const Players = require('./models/Players');
const data = require('./data/liverpoolPlayers.json')
let remove = async (req, res) => {
  try {
    const connected  = await Players.connect();
    const result = await Players.destroy({ where: req.body });
    const closed = await Players.close();
    res.send({total:result})
  } catch (err) {
    res.status(500).send(err)
  }
}
*/

const  Server  = require('./middlewares/Server')
global.__basedir = __dirname;
const server = new Server()